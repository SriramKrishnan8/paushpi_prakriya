#!/usr/bin/env python3

import os
import sys

import re

import argparse

from iw_saFjFA import print_iw


def test():
    """ For internal testing
    """
    
    print_iw("suz")
    print_iw("Bavawuz")
    print_iw("gamLz")
    print_iw("dupacazR")
    print_iw("BU")
    print_iw("tuozSvi")
    print_iw("lazN")
    print_iw("vaxiz")
    print_iw("dukqF")
    print_iw("kwvA")
    print_iw("wumun")
    print_iw("Sap")
    print_iw("NIF")
    print_iw("Bixir")
    print_iw("Cixizr")
    print_iw("FimixAz")
    print_iw("tunaxIz")
    print_iw("RAkan")
    print_iw("RPak")
    print_iw("RTac")
    print_iw("RPa")
    print_iw("jas")
    print_iw("tA")
    print_iw("Sap")
    print_iw("Syan")
    print_iw("gsnu")
    print_iw("Kyun")
    print_iw("Snam")
    print_iw("Sawq")
    print_iw("SAnac")
    print_iw("lyut")
    print_iw("kyac")
    print_iw("KiRNuc")
    print_iw("fi")
    print_iw("GaF")
    print_iw("wasil")
    print_iw("lac")
    print_iw("gmini")
    print_iw("Gan")
    print_iw("Sas")
    print_iw("ka")
    print_iw("Ka")
    print_iw("Namul")
    print_iw("uzCqxizr")
    print_iw("Ihaz")
    print_iw("uzXrasaz")
    print_iw("ozpyAyoz")
    print_iw("ozladiz")
    print_iw("ozvrascUz")
    print_iw("tuozsPUrjAz")
    

parser = argparse.ArgumentParser()
parser.add_argument("-o", "--own")

args = parser.parse_args()

if args.own:
    print_iw(args.own)
else:
    test()
