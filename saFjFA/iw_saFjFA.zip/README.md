# Implementation of iw_saFjFA

The following are the constituents:
1. iw\_saFjFA.py - contains the functions for each of the sUwras that define an iw saFjFA along with the elision function (wasya\_lopaH).
2. util.py - contains various lists like ac, hal, XAwus, prawyayas, etc.
3. test.py - default examples for testing are given. We can also provide our own example.

## Testing

To test the working of iw_saFJFA.py with default examples
```
python3 test.py
```

To test the working of iw_saFJFA.py with own examples
```
python3 test.py -o "dukqF"
```

Replace "dukqF" with your own example in WX notation

## To be done

This module works for a sample set of XAwus and prawyayas. The following are to be updated:
1. List of all XAwus should be stored in the util.py file. At present, there are only a few XAwus.
2. List of all prawyayas are to be enlisted in the util.py file. Additionally, viBakwi\_prawyayas and taxXiwa\_prawyayas are to be maintained separately.
3. For "upaxeSa", all the XAwus, prawyayas, Agamas, AxeSas and terms used in the sUwrapATa are to be enlisted.
