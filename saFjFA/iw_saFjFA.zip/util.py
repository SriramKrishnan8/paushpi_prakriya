#!/usr/bin/env python3

ac = [ 
    "a", "A", "i", "I", "u", "U", 
    "q", "Q", "L", 
    "e", "o", 
    "E", "O" 
]
hal = [ 
    "h", "y", "v", "r", 
    "l", 
    "f", "m", "F", "N", "n", 
    "J", "B", 
    "G", "D", "X", 
    "j", "b", "g", "d", "x", 
    "K", "P", "C", "T", "W", "c", "t", "w",
    "k", "p", 
    "S", "R", "s"
]
anunAsika = "z"
ka_varga = [ "k", "K", "g", "G", "f" ]
ca_varga = [ "c", "C", "j", "J", "F" ]
ta_varga = [ "t", "T", "d", "D", "N" ]
wa_varga = [ "w", "W", "x", "X", "n" ]

XAwus_list = [ 
    "gamLz", "dukqF", "vaxiz", "FimixAz", "tunaxIz", "FikRvixAz", "tukRu",
    "tudu", "dulaBazR", "dupacazR", "uzCqxizr", "Ihaz", 
    "uzXrasaz", "ozpyAyoz", "ozladiz", "ozvrascUz", "tuozsPUrjAz",
]
viBakwi_saFjFA = [ 
    "suz", "O", "jas", "am", "Ot", "Sas", 
    "wip", "was", "Ji", "mahi",
]
all_prawyayas = [ 
    "RAkan", "Rtran", "Rvun",
    "Ra", "Rac", "Rafgavac", "Rikan", "ReNyan", "Rkan", "Rtarac", "RTac", 
    "RTan", "RTal", "RPak", "Ryaf", "RyaF", "RPa",
    "kwvA", "wumun",
    "Sap", "Syan", "gsnu", "Kyun", "KiRNuc", "fi", "GaF", 
    "suz", "O", "jas", "am", "Ot", "Sas", "tA",
    "wip", "was", "Ji", "mahi", "tAp",
    "wasil", "lac", "Gan", "Sas", "ka", "Ka", "gmini", 
    "Namul", "Sawq", "SAnac", "Snam", "lyut", "kyac",
]
R_prawyayas = [
    "RAkan", "Rtran", "Rvun",
    "Ra", "Rac", "Rafgavac", "Rikan", "ReNyan", "Rkan", "Rtarac", "RTac", 
    "RTan", "RTal", "RPak", "Ryaf", "RyaF", "RPa",
]
waxXiwa_prawyayas = [
    "wasil", "lac", "Gan", "Sas", "ka", "Ka", "gmini", 
]
