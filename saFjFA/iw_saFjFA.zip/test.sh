#!/bin/bash

# To test the working of iw_saFJFA.py with default examples
python3 test.py

# To test the working of iw_saFJFA.py with own examples
python3 test.py -o "dukqF"
